'''
Created on 5 Jul 2009

@author: finn
'''

class Hud():
	'''
	classdocs
	'''


	def __init__(self):
		'''
		Constructor
		'''
		