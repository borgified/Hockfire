'''
Created on 3 Oct 2009

@author: finn
'''

class Inventory(object):
	'''
	classdocs
	'''


	def __init__(self, image, shape, maxMass, itemType = None):
		'''
		Constructor
		'''
		
		